# BanRoyale
Source Code meines BanRoyale Event Bots!

### How can I download this bot?
> You can use this bot by clicking on the green `Code` Button on the top of the code. Then click on `Download Zip` and your Code will be moved into your local download folder!

### How can I use the bot?
> First you have to extract the `BanRoyale` folder from the zip archive, which is generated for the download. Then simply move the folder in the directory you want to code in and open the folder witch the IDE of your choice! (Intellij is recommended)

> Now you only have to replace the string shown below with your current bot token from the [Application Dashboard](https://discord.com/developers/applications) and insert the id of the guild the bot should work for

```java
    public static String token = "TOKEN";
    public static String guild = "guildID";
```
